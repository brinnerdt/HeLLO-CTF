# HeLLO CTF 2022
## Tutorial on Fine-grain Hardware Redaction

Welcome to the **HeLLO CTF 2022** competition. This document describes the files shared and provides a tutorial on how you can use the resources we have provided to analyze the transformation of a design through fine-grained redaction of hardware.


<span style="color:red">***By accessing the package, you agree not to redistribute any of the components of this package.***</span>



## Contents

The warm-up package includes the following:

* **c880_transformed.v :** Gate-level netlist of the transformed design. This design needs to configured with the functional bitstream via the configuration ports to restore the original design functionality. 
* **c880_original.v :** Gate-level netlist of the original design. This design can be considered to be an oracle. 
* **c880_transformed_tb.v :** Test bench used to simulate the transformed design. The transformed design is configured with the correct functional bitstream before applying the input vectors from *c880_inputs.txt* for simulation. The outputs generated are recorded in *c880_transformed_outputs.txt*.
* **c880_original_tb.v :** Test bench used to simulate the original design. The input vectors are read in from *c880_inputs.txt* and the outputs generated are recorded in *c880_original_outputs.txt*.
* **c880_inputs.txt :** A file containing 10001 input vectors used by the test benches for simulation.
* **c880_original_outputs.txt :** Simulation-generated outputs of the original design.
* **c880_transformed_outputs.txt :** Simulation-generated outputs of the transformed design.
* **c880_functional_bitstream.txt :** The functional bitstream required to restore the true functionality of the original design. Each line in this file represents a single bit in the bitstream, e.g. the first line corresponds to cfg_input_0 in the transformed design.
* **sim_directives.v :** A Verilog file containing simulation directives, e.g timescale.
* **transformation_summary.txt :** A brief summary of the transformation process.
* **lib/ :** A directory containing the synthesis and simulation library files.

**The designs in the warm-up package have been generated using the c880 ISCAS 85 benchmark [1].** 

### Standard Cell Library ###

We use the standard cells available as part of the SkyWater Technology Foundry's 130nm node [2] for synthesis and simulation of designs shared as part of this warm-up package. The library files used can be found inside the ***lib/*** directory:
* **sky130_uf_mod.v :** SkyWater Library in Verilog format. **[USED for simualtion.]** 
* **sky130_uf_mod.lib :** SkyWater Library in Liberty format. **[USED for synthesis.]** 


## Simulation Commands

We have provided test benches for simulating the original and transformed designs and verification of the bitstream. We recommend using ***Synopsys VCS*** for simulation using the commands below:

***Simulation of original design :***
```
$ vcs -full64 -R directives.v c880_original.v c880_original_tb.v -v lib/sky130_uf_mod.v 
```

***Simulation of transformed design :***
```
$ vcs -full64 -R directives.v c880_transformed.v c880_transformed_tb.v -v lib/sky130_uf_mod.v 
```

Both the original and the transformed design is simulated using the same sequence of input vectors (*c880_inputs.txt*). The transformed design is configured in the test bench (*c880_transformed_tb.v*) using the functional bitstream before applying the input vectors. This restores the true functionality of the original design. This can be verified by comparing the original and transformed outputs (*c880_original_outputs.txt* and *c880_transformed_outputs.txt*). If the transformed design is not configured correctly, simulation will result in mismatched outputs between the original and transformed designs. In the example provided, the transformed design is correctly configured.



## Tasks

This tutorial is designed to help you become more familiar with the netlists you will receive in the challenge round. NOPOINTS WILL BE AWADED FOR EVALUATION OF THE WARM-UP DESIGN. However, you are more than welcome toreport the insight on your analysis.



## Contacts

If you have any queries, let us know:
* Rasheed A. Almawazan @ <ralmawazan@ufl.edu>
* Md Moshiur Rahman @ <rahman.m@ufl.edu>
* Aritra Dasgupta @ <aritradasgupta@ufl.edu>



## References

1. **ISCAS 85 benchmarks :** https://urldefense.proofpoint.com/v2/url?u=http-3A__www.pld.ttu.ee_-7Emaksim_benchmarks_iscas85_verilog_&d=DwIGAw&c=sJ6xIWYx-zLMB3EPkvcnVg&r=bJXdvfxIRFRkEhmDGtdA_oUg3kuSkVdvW8TDjxycSiY&m=EjOHmkx3o78D9vkEwOR7QSDdVLprO55AfXK3RuFxGPc&s=RoGPvpmTe9KG7IFMLuFV6_GA7jf9Rb79Y3Kfg5aB7jc&e= 
2. **SkyWater Technology Foundry's 130nm node:** https://github.com/google/skywater-pdk