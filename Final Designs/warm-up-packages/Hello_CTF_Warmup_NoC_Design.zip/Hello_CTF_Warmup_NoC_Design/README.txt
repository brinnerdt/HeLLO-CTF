// Inside the RTL folder, you can find the all required files for this NoC Model
// The powerpoint can give you a high level overview of the model

// Top Module for Full design is: 	design1_edited.v
// Top Module for CPU: 			design1_edited_cpu.v
// Top Module for Interconnect: 	design1_edited_mm_interconnect_0.v
// Top Module for Memory: 		design1_edited_onchip_memory.v
// Top Module for UART: 		design1_edited_jtag_uart.v



// The simple design provided consists of an Intel NIOS II processor, an on chip memory and a UART. 
// The SoC as a whole consists of a simple clock and Reset as the inputs. 
// We have added the NoC Routing Table - Routing topology Transformation on two of the 4 routers in the design, that can be found in the file "design1_edited_mm_interconnect_0.v", with the module name consisting of the string 'router'. 
// In an ideal setup, the transformed design would behave exactly as intended when provided with the right activation package. 
// Here, currently the activation package would be provided via the MUX select lines
// A very basic test bench with the (design1_edited_tb.v) with inputs as clock and reset are provided for evaluation. 

Please contact us if you are facing any issues.

