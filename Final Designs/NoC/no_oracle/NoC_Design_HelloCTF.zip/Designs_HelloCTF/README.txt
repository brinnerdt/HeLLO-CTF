##############################
// Design Details
// Tools Required
	Quartus Prime pro 21.3
	Device: Agilex
// For opening the design:
	1. design1.qpf 
	2. design1.qsys

	design1.qpf file opens the project in quatus 
	design1.qsys opens the project in Platform designer
	
// All IP files are inside the ip directory

// If you have any questions regarding the design feel free to contact
// Contact deatils are given in HelloCTF site
